require("dotenv").config()
const {MONGODBURI}
const mongoose = require("mongoose")
const config = {useNewuRLParser: true, useUnifiedTopology: true}

//* Connect to monogo
mongoose.connect(MONGODBURI, config)

//*Events
mongoose.connection
.on("open", () => console.log("You are connected to mongo"))
.on("close", () => console.log("You are disconnected to mongo"))
.on("error", () => console.log(error))

module.exports = mongoose