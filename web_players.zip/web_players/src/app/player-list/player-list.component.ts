import { playerService } from '../player-service.service';
import { Component, OnInit } from '@angular/core';
import { playerTeam } from 'playerTeam';

@Component({
  selector: 'app-player-list',
  templateUrl: './player-list.component.html',
  styleUrls: ['./player-list.component.css']
})
export class PlayerListComponent implements OnInit {

  players: playerTeam[] = []

  constructor(private playerservice: playerService) { }

  ngOnInit(): void {
    this.displayPlayer()
  }

  displayplyer() {
    this.playerservice.readPlyers().subscribe(x => {
      this.players = x
      console.log(x)
    })
    
  }
}
