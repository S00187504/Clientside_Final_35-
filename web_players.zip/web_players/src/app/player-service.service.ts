import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http'
import { Observable } from 'rxjs';
import { playerTeam } from 'playerTeam'

@Injectable({
  providedIn: 'root'
})
export class playerService {


  myAPI:string = "http://localhost:3000"

  constructor(private http: HttpClient) { }

  readPlayers() : Observable <playerTeam[]> {
    return this.http.get<playerTeam[]>(`${this.myAPI}/players`)
  }

  addPlayers(players: playerTeam): Observable <playerTeam> {
      return this.http.post<playerTeam>(`${this.myAPI}/players`, players)
  }
}