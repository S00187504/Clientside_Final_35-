import { Component, Input, OnInit } from '@angular/core';
import { PlayerNumber } from 'playerModel';

@Component({
  selector: 'app-player-component',
  templateUrl: './player-component.component.html',
  styleUrls: ['./player-component.component.css']
})
export class PlayerComponentComponent implements OnInit {

  @Input() player: playerNumber;


  constructor() { 

  }

  ngOnInit(): void {
    console.log(this.player)
  }
  

}
