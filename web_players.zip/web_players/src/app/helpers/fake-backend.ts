// import { Observable, of,  } from 'rxjs';
// import { HttpHandler, HttpInterceptor, HttpRequest, HttpResponse, HttpEvent } from "@angular/common/http";
// import { Injectable } from "@angular/core";

// const accountsKey = 'angular-10-facebook-login-accounts';
// let accounts = JSON.parse(localStorage.getItem(accountsKey)) || [];

// @Injectable()
// export class FakeBackendInterceptor implements HttpInterceptor {
//     intercept(request: HttpRequest<any>, next: HttpHandler): Observable
//     const
// }