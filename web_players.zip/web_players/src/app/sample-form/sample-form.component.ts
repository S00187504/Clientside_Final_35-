import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators, ReactiveFormsModule } from '@angular/forms';
import { playerService } from './../player-service.service';

@Component({
  selector: 'app-sample-form',
  templateUrl: './sample-form.component.html',
  styleUrls: ['./sample-form.component.css']
})
export class SampleFormComponent implements OnInit {

  playerservice: playerService;

  constructor(playerservice : playerService) {
    this.playerservice = playerservice
   }

   playerForm = new FormGroup({
    playerID: new FormControl('', Validators.min(1)),
    playerTeam: new FormControl('', Validators.required),
    playerNumber: new FormControl('', Validators.required),
    playerAge: new FormControl('', Validators.min(4)),
    playerNationality: new FormControl('', Validators.required)
  });


  ngOnInit(): void {
  }

  message: string = "";

  public showMyMessage = false

  btnSubmit() {
    console.log(`Welcome to PlayerDB` + JSON.stringify(this.playerForm.value));
    this.playerservice.addPlayer(this.playerForm.value)
    .subscribe({
      next: players => {
        console.log(JSON.stringify(players) + 'has been added to the database');
        this.message = "A new player has been added to the database"
      }
    })
  }

  get playerID() {
    return this.playerForm.get('playerID');
  }

  get playerTeam() {
    return this.playerForm.get('playerTeam');
  }

  get playerNumber() {
    return this.playerForm.get('playerModel');
  }


  get PlayerAge() {
    return this.playerForm.get('playerAge');
  }

  get playerNationality() {
    return this.playerForm.get('playerNationality');
  }
}
