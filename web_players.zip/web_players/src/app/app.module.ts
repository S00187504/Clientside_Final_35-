import { UserService } from './user.service';
import { Router, RouterModule, Routes } from '@angular/router';
import { BrowserModule } from '@angular/platform-browser';
import { APP_INITIALIZER, NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { HttpClientModule } from '@angular/common/http'
import { NgbModule } from '@ng-bootstrap/ng-bootstrap'
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { SampleFormComponent } from './sample-form/sample-form.component';
import { PlayerListComponent } from './player-list/player-list.component';
import { PlayerComponentComponent } from './player-component/player-component.component';
import { AuthPageComponent } from './auth-page/auth-page.component';
import { AuthenticationComponent } from './authentication/authentication.component';
import { appInitializer } from './helpers/app.initialiser';


@NgModule({
  declarations: [
    AppComponent,
    SampleFormComponent,
    PlayerListComponent,
    PlayerComponentComponent,
    AuthPageComponent,
    AuthenticationComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule,
    NgbModule,
    ReactiveFormsModule,
    FormsModule
    ],
  providers: [
    // {
    //   provide: APP_INITIALIZER,
    //   useFactory: appInitializer,
    //   multi: true,
    //   deps: [UserService]
    // },
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }