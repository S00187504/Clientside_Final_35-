export interface playerModel {
    playerID: number,
    playerTeam: string,
    playerNumber: string,
    playerAge: number,
    playerNationality: string
}